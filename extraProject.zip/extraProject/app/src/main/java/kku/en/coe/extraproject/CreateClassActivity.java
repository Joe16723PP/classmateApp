package kku.en.coe.extraproject;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class CreateClassActivity extends AppCompatActivity implements NumberPicker.OnValueChangeListener, View.OnClickListener {


    private TextView startDate, endDate, startTime, endTime;
    private CheckBox cbMon, cbTue, cbWed, cbThu, cbFri, cbSat, cbSun;
    private DatePickerDialog.OnDateSetListener startDateListener, endDateListener;
    private TimePickerDialog.OnTimeSetListener startTimeListener, endTimeListener;
    String AmPm, sTime, eTime, sDate, eDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_class);

        startDate = findViewById(R.id.start_datePicker);
        endDate = findViewById(R.id.end_datePicker);
        startTime = findViewById(R.id.start_timePicker);
        endTime = findViewById(R.id.end_timePicker);
        cbMon = findViewById(R.id.cbMon);
        cbTue = findViewById(R.id.cbTue);
        cbWed = findViewById(R.id.cbWed);
        cbThu = findViewById(R.id.cbThu);
        cbFri = findViewById(R.id.cbFri);
        cbSat = findViewById(R.id.cbSat);
        cbSun = findViewById(R.id.cbSun);


        startTime.setOnClickListener(this);
        endTime.setOnClickListener(this);
        startDate.setOnClickListener(this);
        endDate.setOnClickListener(this);

        getInit();
        
    }

    private void getInit() {
        Bundle bn = getIntent().getExtras();
        Double lat = bn.getDouble("lat");
        Double lng = bn.getDouble("lng");
        Toast.makeText(CreateClassActivity.this, "lat: " + lat + " lng: " + lng, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onClick(View v) {

        Intent intent = new Intent(CreateClassActivity.this, TeacherMainActivity.class);
        intent.putExtra("startTime" , sTime);
        intent.putExtra("endTime" , eTime);
        intent.putExtra("startDate" , sDate);
        intent.putExtra("endDate" , eDate);
        intent.putExtra("cbMon" , cbMon.isChecked());
        intent.putExtra("cbTue" , cbTue.isChecked());
        intent.putExtra("cbWed" , cbWed.isChecked());
        intent.putExtra("cbThu" , cbThu.isChecked());
        intent.putExtra("cbFri" , cbFri.isChecked());
        intent.putExtra("cbSat" , cbSat.isChecked());
        intent.putExtra("cbSun" , cbSun.isChecked());
        startActivity(intent);

        Calendar cal_StartTime = Calendar.getInstance();
        Calendar cal_StartDate = Calendar.getInstance();
        int hour = cal_StartTime.get(Calendar.HOUR);
        int minute = cal_StartTime.get(Calendar.MINUTE);
        int year = cal_StartDate.get(Calendar.YEAR);
        int month = cal_StartDate.get(Calendar.MONTH);
        int day = cal_StartDate.get(Calendar.DAY_OF_MONTH);

        if (v == startTime) {
            TimePickerDialog dialog_StartTime = new TimePickerDialog(
                    CreateClassActivity.this,android.R.style.Theme_DeviceDefault_Light_Dialog,
                    startTimeListener, hour, minute, false);

            dialog_StartTime.getWindow().setBackgroundDrawable(new ColorDrawable(Color.LTGRAY));
            dialog_StartTime.show();

            startTimeListener = new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    if (hourOfDay >= 12){
                        AmPm = "PM";
                    } else {
                        AmPm = "AM";
                    }
                    startTime.setText(String.format("%02d:%02d", hourOfDay, minute) + " " + AmPm);
                    sTime = startTime.getText().toString();
                }
            };
        }

        else if (v == endTime){
            TimePickerDialog dialog_StartTime = new TimePickerDialog(
                    CreateClassActivity.this,android.R.style.Theme_DeviceDefault_Light_Dialog,
                    endTimeListener, hour, minute, false);

            dialog_StartTime.getWindow().setBackgroundDrawable(new ColorDrawable(Color.LTGRAY));
            dialog_StartTime.show();

            endTimeListener = new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    if (hourOfDay >= 12){
                        AmPm = "PM";
                    } else {
                        AmPm = "AM";
                    }
                    endTime.setText(String.format("%02d:%02d", hourOfDay, minute) + " " + AmPm);
                    eTime = endTime.getText().toString();
                }
            };
        }

        else if (v == startDate) {
            DatePickerDialog dialog_StartDate = new DatePickerDialog(
                    CreateClassActivity.this,
                    android.R.style.Theme_DeviceDefault_Light_Dialog, startDateListener, year, month, day);

            dialog_StartDate.getWindow().setBackgroundDrawable(new ColorDrawable(Color.LTGRAY));
            dialog_StartDate.show();

            startDateListener = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    month = month + 1;
                    String date_start = dayOfMonth + "/" + month + "/" + year;
                    startDate.setText(date_start);
                    Toast.makeText(getApplicationContext(),date_start,Toast.LENGTH_LONG).show();

                    sDate = startDate.getText().toString();
                }
            };
        }
        else if (v == endDate) {
            DatePickerDialog dialog_EndDate = new DatePickerDialog(
                    CreateClassActivity.this,
                    android.R.style.Theme_DeviceDefault_Light_Dialog,endDateListener,year,month,day);

            dialog_EndDate.getWindow().setBackgroundDrawable(new ColorDrawable(Color.LTGRAY));
            dialog_EndDate.show();

            endDateListener = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    month = month + 1;
                    String date_end = dayOfMonth + "/" + month + "/" + year;
                    endDate.setText(date_end);
                    Toast.makeText(getApplicationContext(),date_end,Toast.LENGTH_LONG).show();

                    eDate = endDate.getText().toString();
                }
            };

        }
    }

    public void onCheckboxClicked(View v){
        boolean checked = ((CheckBox) v).isChecked();

        switch (v.getId()) {
            case R.id.cbMon:
                if (checked){
                    Toast.makeText(getApplicationContext(), "Choose Monday", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getApplicationContext(), "Un-Checked", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.cbTue:
                if (checked){
                    Toast.makeText(getApplicationContext(), "Choose Tuesday", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getApplicationContext(), "Un-Checked", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.cbWed:
                if (checked){
                    Toast.makeText(getApplicationContext(), "Choose Wednesday", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getApplicationContext(), "Un-Checked", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.cbThu:
                if (checked){
                    Toast.makeText(getApplicationContext(), "Choose Thursday", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getApplicationContext(), "Un-Checked", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.cbFri:
                if (checked){
                    Toast.makeText(getApplicationContext(), "Choose Friday", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getApplicationContext(), "Un-Checked", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.cbSat:
                if (checked){
                    Toast.makeText(getApplicationContext(), "Choose Saturday", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getApplicationContext(), "Un-Checked", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.cbSun:
                if (checked){
                    Toast.makeText(getApplicationContext(), "Choose Sunday", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getApplicationContext(), "Un-Checked", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    @Override
    public void onValueChange(NumberPicker picker, int oldVal, int newVal) {

    }
}
